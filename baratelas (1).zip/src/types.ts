export type Category = 'Celulares' | 'Notebooks' | 'Tablets' | 'Monitores Gamer' | 'TVs';

export interface Product {
  id: string;
  title: string;
  price: number;
  originalPrice: number;
  store: string;
  imageUrl: string;
  affiliateLink: string;
  category: Category;
  specs: Record<string, string | number>;
  techScore?: number;
  rating?: number;
  isOfferOfDay?: boolean;
}

export interface Comment {
  id: string;
  productId: string;
  userId: string;
  userName: string;
  userPhoto?: string;
  text: string;
  rating: number;
  timestamp: number;
}

export interface TechScoreCriteria {
  name: string;
  weight: number;
}

export const CATEGORY_CRITERIA: Record<Category, TechScoreCriteria[]> = {
  'Celulares': [
    { name: 'Desempenho', weight: 0.3 },
    { name: 'Câmera', weight: 0.25 },
    { name: 'Bateria', weight: 0.15 },
    { name: 'Tela', weight: 0.15 },
    { name: 'Custo-Benefício', weight: 0.15 },
  ],
  'Notebooks': [
    { name: 'Processador', weight: 0.3 },
    { name: 'RAM/Armazenamento', weight: 0.2 },
    { name: 'GPU', weight: 0.2 },
    { name: 'Portabilidade', weight: 0.15 },
    { name: 'Tela', weight: 0.15 },
  ],
  'Tablets': [
    { name: 'Tela', weight: 0.3 },
    { name: 'Desempenho', weight: 0.25 },
    { name: 'Bateria', weight: 0.15 },
    { name: 'Portabilidade', weight: 0.15 },
    { name: 'Custo-Benefício', weight: 0.15 },
  ],
  'Monitores Gamer': [
    { name: 'Frequência/Resposta', weight: 0.35 },
    { name: 'Resolução/Cores', weight: 0.25 },
    { name: 'Tamanho/Painel', weight: 0.15 },
    { name: 'Construção', weight: 0.1 },
    { name: 'Custo-Benefício', weight: 0.15 },
  ],
  'TVs': [
    { name: 'Qualidade de Imagem', weight: 0.4 },
    { name: 'Som', weight: 0.15 },
    { name: 'Smart/Sistema', weight: 0.15 },
    { name: 'Conectividade', weight: 0.15 },
    { name: 'Custo-Benefício', weight: 0.15 },
  ],
};
