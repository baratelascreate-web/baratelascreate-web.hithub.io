import React from 'react';
import { motion } from 'motion/react';
import { FileText } from 'lucide-react';

const TermsOfUse: React.FC = () => {
  return (
    <main className="max-w-4xl mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center">
            <FileText className="text-emerald-500 w-6 h-6" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Termos de Uso</h1>
        </div>

        <section className="glass-card p-8 space-y-6 text-zinc-400 leading-relaxed">
          <h2 className="text-xl font-bold text-white">1. Aceitação dos Termos</h2>
          <p>
            Ao acessar o site BARATELAS, você concorda em cumprir estes termos de serviço, todas as leis e regulamentos aplicáveis ​​e concorda que é responsável pelo cumprimento de todas as leis locais aplicáveis.
          </p>

          <h2 className="text-xl font-bold text-white">2. Uso de Licença</h2>
          <p>
            É concedida permissão para baixar temporariamente uma cópia dos materiais (informações ou software) no site BARATELAS, apenas para visualização transitória pessoal e não comercial.
          </p>

          <h2 className="text-xl font-bold text-white">3. Isenção de Responsabilidade</h2>
          <p>
            Os materiais no site do BARATELAS são fornecidos 'como estão'. BARATELAS não oferece garantias, expressas ou implícitas, e, por este meio, isenta e nega todas as outras garantias, incluindo, sem limitação, garantias implícitas ou condições de comercialização, adequação a um fim específico ou não violação de propriedade intelectual ou outra violação de direitos.
          </p>

          <h2 className="text-xl font-bold text-white">4. Limitações</h2>
          <p>
            Em nenhum caso o BARATELAS ou seus fornecedores serão responsáveis ​​por quaisquer danos (incluindo, sem limitação, danos por perda de dados ou lucro ou devido a interrupção dos negócios) decorrentes do uso ou da incapacidade de usar os materiais em BARATELAS.
          </p>

          <h2 className="text-xl font-bold text-white">5. Precisão dos Materiais</h2>
          <p>
            Os materiais exibidos no site do BARATELAS podem incluir erros técnicos, tipográficos ou fotográficos. BARATELAS não garante que qualquer material em seu site seja preciso, completo ou atual. BARATELAS pode fazer alterações nos materiais contidos em seu site a qualquer momento, sem aviso prévio.
          </p>

          <h2 className="text-xl font-bold text-white">6. Modificações</h2>
          <p>
            O BARATELAS pode revisar estes termos de serviço do site a qualquer momento, sem aviso prévio. Ao usar este site, você concorda em ficar vinculado à versão atual desses termos de serviço.
          </p>
        </section>
      </motion.div>
    </main>
  );
};

export default TermsOfUse;
