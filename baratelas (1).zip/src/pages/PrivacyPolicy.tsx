import React from 'react';
import { motion } from 'motion/react';
import { Shield } from 'lucide-react';

const PrivacyPolicy: React.FC = () => {
  return (
    <main className="max-w-4xl mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-8"
      >
        <div className="flex items-center gap-4 mb-8">
          <div className="w-12 h-12 bg-emerald-500/10 rounded-xl flex items-center justify-center">
            <Shield className="text-emerald-500 w-6 h-6" />
          </div>
          <h1 className="text-4xl font-bold tracking-tight">Política de Privacidade</h1>
        </div>

        <section className="glass-card p-8 space-y-6 text-zinc-400 leading-relaxed">
          <p>
            A sua privacidade é importante para nós. É política do BARATELAS respeitar a sua privacidade em relação a qualquer informação sua que possamos coletar no site BARATELAS, e outros sites que possuímos e operamos.
          </p>

          <h2 className="text-xl font-bold text-white">1. Coleta de Informações</h2>
          <p>
            Solicitamos informações pessoais apenas quando realmente precisamos delas para lhe fornecer um serviço. Fazemo-lo por meios justos e legais, com o seu conhecimento e consentimento. Também informamos por que estamos coletando e como será usado.
          </p>

          <h2 className="text-xl font-bold text-white">2. Uso de Cookies</h2>
          <p>
            Utilizamos cookies para entender como você interage com nosso site e para melhorar sua experiência. Os cookies nos ajudam a lembrar suas preferências e a oferecer conteúdo relevante.
          </p>

          <h2 className="text-xl font-bold text-white">3. Links de Afiliados</h2>
          <p>
            O BARATELAS participa de programas de afiliados. Quando você clica em um link de oferta e realiza uma compra, podemos receber uma comissão. Isso não altera o preço final para você e nos ajuda a manter o serviço gratuito e atualizado.
          </p>

          <h2 className="text-xl font-bold text-white">4. Segurança dos Dados</h2>
          <p>
            Apenas retemos as informações coletadas pelo tempo necessário para fornecer o serviço solicitado. Quando armazenamos dados, os protegemos dentro de meios comercialmente aceitáveis ​​para evitar perdas e roubos, bem como acesso, divulgação, cópia, uso ou modificação não autorizados.
          </p>

          <h2 className="text-xl font-bold text-white">5. Links Externos</h2>
          <p>
            Nosso site pode ter links para sites externos que não são operados por nós. Esteja ciente de que não temos controle sobre o conteúdo e práticas desses sites e não podemos aceitar responsabilidade por suas respectivas políticas de privacidade.
          </p>

          <p className="pt-4 border-t border-white/5 text-sm">
            Esta política é efetiva a partir de Fevereiro de 2026.
          </p>
        </section>
      </motion.div>
    </main>
  );
};

export default PrivacyPolicy;
