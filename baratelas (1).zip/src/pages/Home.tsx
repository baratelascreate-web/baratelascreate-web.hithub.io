import { useEffect, useState } from 'react';
import { collection, query, where, getDocs, limit, orderBy } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Category, Comment } from '../types';
import { calculateTechScore } from '../utils';
import ProductCard from '../components/ProductCard';
import CategorySection from '../components/CategorySection';
import { motion } from 'motion/react';
import { Zap, ChevronRight, MessageSquare, Star, Cpu } from 'lucide-react';
import { Link } from 'react-router-dom';
import PublicityBanner from '../components/PublicityBanner';

export default function Home() {
  const [offersOfDay, setOffersOfDay] = useState<Product[]>([]);
  const [categoryProducts, setCategoryProducts] = useState<Record<Category, Product[]>>({
    'Celulares': [],
    'Notebooks': [],
    'Tablets': [],
    'Monitores Gamer': [],
    'TVs': []
  });
  const [recentComments, setRecentComments] = useState<Comment[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      try {
        const productsRef = collection(db, 'produtos');
        
        // Fetch Offers of the Day
        const offersQuery = query(productsRef, where('isOfferOfDay', '==', true), limit(4));
        const offersSnap = await getDocs(offersQuery);
        const offers = offersSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Product));
        setOffersOfDay(offers);

        // Fetch Top Rated for each category
        const categories: Category[] = ['Celulares', 'Notebooks', 'Tablets', 'Monitores Gamer', 'TVs'];
        const newCategoryProducts = { ...categoryProducts };

        for (const cat of categories) {
          const catQuery = query(productsRef, where('category', '==', cat), limit(8));
          const catSnap = await getDocs(catQuery);
          const products = catSnap.docs.map(doc => {
            const p = { id: doc.id, ...doc.data() } as Product;
            return { ...p, techScore: calculateTechScore(p) };
          });
          
          // Sort by tech score descending
          newCategoryProducts[cat] = products.sort((a, b) => (b.techScore || 0) - (a.techScore || 0));
        }

        setCategoryProducts(newCategoryProducts);

        // Fetch Recent Comments
        const commentsQuery = query(collection(db, 'comentarios'), orderBy('timestamp', 'desc'), limit(4));
        const commentsSnap = await getDocs(commentsQuery);
        const comments = commentsSnap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment));
        setRecentComments(comments);
      } catch (error) {
        // Silently handle error
        // Fallback with mock data for demo if firebase is not configured
        const mockProducts: Product[] = [
          {
            id: '1',
            title: 'iPhone 15 Pro Max 256GB Titanium',
            price: 8499,
            originalPrice: 10999,
            store: 'Amazon',
            imageUrl: 'https://picsum.photos/seed/iphone/400/400',
            affiliateLink: '#',
            category: 'Celulares',
            specs: { cpu: 'A17 Pro', ram: '8GB' },
            isOfferOfDay: true
          },
          {
            id: '2',
            title: 'MacBook Air M2 13" 8GB 256GB',
            price: 7299,
            originalPrice: 9999,
            store: 'Mercado Livre',
            imageUrl: 'https://picsum.photos/seed/macbook/400/400',
            affiliateLink: '#',
            category: 'Notebooks',
            specs: { cpu: 'M2', ram: '8GB' },
            isOfferOfDay: true
          },
          {
            id: '3',
            title: 'Samsung Galaxy S24 Ultra 512GB',
            price: 6999,
            originalPrice: 8999,
            store: 'Magalu',
            imageUrl: 'https://picsum.photos/seed/s24/400/400',
            affiliateLink: '#',
            category: 'Celulares',
            specs: { cpu: 'Snapdragon 8 Gen 3', ram: '12GB' },
            isOfferOfDay: true
          },
          {
            id: '4',
            title: 'iPad Pro M2 11" 128GB Wi-Fi',
            price: 6499,
            originalPrice: 7999,
            store: 'Kabum',
            imageUrl: 'https://picsum.photos/seed/ipad/400/400',
            affiliateLink: '#',
            category: 'Tablets',
            specs: { cpu: 'M2', ram: '8GB' },
            isOfferOfDay: true
          }
        ];
        setOffersOfDay(mockProducts);
        
        // Fill other categories with mock data too
        const cats: Category[] = ['Celulares', 'Notebooks', 'Tablets', 'Monitores Gamer', 'TVs'];
        const filledMock: any = {};
        cats.forEach(c => {
          filledMock[c] = mockProducts.map(p => ({...p, category: c, id: Math.random().toString(), techScore: calculateTechScore({...p, category: c})}));
        });
        setCategoryProducts(filledMock);
      } finally {
        setLoading(false);
      }
    }

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  return (
    <main className="max-w-7xl mx-auto px-4 py-8">
      {/* Tech Score Banner */}
      <motion.section 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12"
      >
        <Link to="/como-funciona">
          <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-600 to-blue-700 p-8 md:p-12 group cursor-pointer border border-white/10">
            <div className="relative z-10 max-w-2xl">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4 tracking-tight">
                Como funciona o <span className="text-emerald-300">Tech Score?</span>
              </h2>
              <p className="text-emerald-50/80 text-lg mb-6 leading-relaxed">
                Descubra como nossa metodologia exclusiva avalia cada produto para garantir que você faça a melhor escolha técnica.
              </p>
              <div className="inline-flex items-center gap-2 bg-white text-emerald-700 font-bold px-6 py-3 rounded-xl group-hover:gap-4 transition-all shadow-lg">
                Saiba Mais
                <ChevronRight className="w-5 h-5" />
              </div>
            </div>
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-emerald-400/20 rounded-full translate-y-1/2 -translate-x-1/2 blur-2xl" />
          </div>
        </Link>
      </motion.section>

      <PublicityBanner 
        imageUrl="https://picsum.photos/seed/tech-ad-1/1200/300" 
        className="mb-16"
      />

      {/* Feature Cards from Snippet */}
      <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <motion.div 
          whileHover={{ y: -5 }}
          className="glass-card p-6 border border-white/5 flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center shrink-0">
            <Star className="text-emerald-500 w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-white">Score Inteligente</h3>
            <p className="text-xs text-zinc-500">Algoritmo que analisa custo-benefício real</p>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ y: -5 }}
          className="glass-card p-6 border border-white/5 flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center shrink-0">
            <Zap className="text-blue-500 w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-white">Melhores Preços</h3>
            <p className="text-xs text-zinc-500">Monitoramento constante das maiores lojas</p>
          </div>
        </motion.div>
        
        <motion.div 
          whileHover={{ y: -5 }}
          className="glass-card p-6 border border-white/5 flex items-center gap-4"
        >
          <div className="w-12 h-12 bg-purple-500/10 rounded-2xl flex items-center justify-center shrink-0">
            <Cpu className="text-purple-500 w-6 h-6" />
          </div>
          <div>
            <h3 className="font-bold text-white">Análise Técnica</h3>
            <p className="text-xs text-zinc-500">Especificações traduzidas para você</p>
          </div>
        </motion.div>
      </section>

      {/* Hero / Offers of Day */}
      <section className="mb-16">
        <div className="flex items-center gap-2 mb-8">
          <Zap className="text-yellow-400 w-6 h-6 fill-yellow-400" />
          <h2 className="text-3xl font-bold tracking-tight">Ofertas do Dia</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {offersOfDay.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      <PublicityBanner 
        imageUrl="https://picsum.photos/seed/tech-ad-2/1200/300" 
        className="mb-16"
      />

      {/* Category Sections */}
      {(Object.entries(categoryProducts) as [Category, Product[]][]).map(([category, products]) => (
        <CategorySection key={category} category={category} products={products} />
      ))}

      <PublicityBanner 
        imageUrl="https://picsum.photos/seed/tech-ad-3/1200/300" 
        className="mt-16"
      />

      {/* Recent Comments Section */}
      <section className="mt-24 mb-16">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-2">
            <MessageSquare className="text-emerald-500 w-6 h-6" />
            <h2 className="text-3xl font-bold tracking-tight">O que a comunidade está dizendo</h2>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {recentComments.length > 0 ? (
            recentComments.map((comment) => (
              <motion.div
                key={comment.id}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                className="glass-card p-6 flex flex-col h-full"
              >
                <div className="flex items-center gap-3 mb-4">
                  {comment.userPhoto ? (
                    <img src={comment.userPhoto} alt={comment.userName} className="w-8 h-8 rounded-full" />
                  ) : (
                    <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500 text-xs font-bold">
                      {comment.userName[0]}
                    </div>
                  )}
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-xs truncate">{comment.userName}</p>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((s) => (
                        <Star key={s} className={`w-2.5 h-2.5 ${s <= comment.rating ? 'text-yellow-500 fill-yellow-500' : 'text-zinc-800'}`} />
                      ))}
                    </div>
                  </div>
                </div>
                <p className="text-zinc-400 text-sm line-clamp-3 mb-6 flex-1 italic">
                  "{comment.text}"
                </p>
                <Link
                  to={`/produto/${comment.productId}#comments`}
                  className="text-emerald-500 hover:text-emerald-400 text-xs font-bold flex items-center gap-1 group"
                >
                  Ver Mais
                  <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Link>
              </motion.div>
            ))
          ) : (
            // Empty state or placeholders
            [1, 2, 3, 4].map(i => (
              <div key={i} className="glass-card p-6 animate-pulse">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-8 h-8 rounded-full bg-zinc-800" />
                  <div className="flex-1">
                    <div className="h-3 w-20 bg-zinc-800 rounded mb-1" />
                    <div className="h-2 w-12 bg-zinc-800 rounded" />
                  </div>
                </div>
                <div className="h-4 w-full bg-zinc-800 rounded mb-2" />
                <div className="h-4 w-2/3 bg-zinc-800 rounded mb-6" />
                <div className="h-3 w-16 bg-zinc-800 rounded" />
              </div>
            ))
          )}
        </div>
      </section>
    </main>
  );
}
