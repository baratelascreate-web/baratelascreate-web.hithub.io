import { motion } from 'motion/react';
import { Info, CheckCircle2, BarChart3, ShieldCheck, Zap, TrendingUp } from 'lucide-react';
import { CATEGORY_CRITERIA } from '../types';

export default function HowItWorks() {
  return (
    <main className="max-w-4xl mx-auto px-4 py-16">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-16"
      >
        <div className="inline-flex items-center justify-center w-16 h-16 bg-emerald-500/10 rounded-2xl mb-6">
          <BarChart3 className="w-8 h-8 text-emerald-500" />
        </div>
        <h1 className="text-4xl md:text-5xl font-bold mb-6 tracking-tight">
          Entenda o <span className="text-emerald-500">Tech Score</span>
        </h1>
        <p className="text-xl text-zinc-400 leading-relaxed">
          Nossa metodologia exclusiva para ajudar você a escolher o melhor produto tecnológico 
          sem cair em armadilhas de marketing.
        </p>
      </motion.div>

      <div className="space-y-12">
        <section className="glass-card p-8">
          <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <ShieldCheck className="text-emerald-500" />
            O que é o Tech Score?
          </h2>
          <p className="text-zinc-400 leading-relaxed">
            O Tech Score é uma nota de 0 a 10 atribuída a cada produto em nossa plataforma. 
            Diferente de outros sites que apenas mostram o preço, nós analisamos as especificações 
            técnicas reais e as comparamos com o padrão atual do mercado.
          </p>
        </section>

        <section className="grid md:grid-cols-2 gap-8">
          <div className="glass-card p-8">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <Zap className="text-yellow-400" />
              Critérios de Avaliação
            </h3>
            <p className="text-zinc-400 mb-6">
              Para cada categoria, selecionamos os 5 critérios mais importantes. 
              Cada critério tem um peso diferente na nota final.
            </p>
            <ul className="space-y-3">
              <li className="flex items-start gap-2 text-sm text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Análise de hardware bruto (CPU, GPU, RAM)</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Qualidade de construção e materiais</span>
              </li>
              <li className="flex items-start gap-2 text-sm text-zinc-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-500 mt-0.5 shrink-0" />
                <span>Tecnologia de tela e fidelidade de cores</span>
              </li>
            </ul>
          </div>

          <div className="glass-card p-8">
            <h3 className="text-xl font-bold mb-4 flex items-center gap-2">
              <TrendingUp className="text-blue-400" />
              Custo-Benefício
            </h3>
            <p className="text-zinc-400">
              O preço é um fator crucial. Um produto excelente com preço abusivo terá um 
              Tech Score menor do que um produto bom com preço justo. Nossa inteligência 
              cruza dados de performance vs. preço em tempo real.
            </p>
          </div>
        </section>

        <section className="glass-card p-8">
          <h2 className="text-2xl font-bold mb-8">Pesos por Categoria</h2>
          <div className="grid sm:grid-cols-2 gap-8">
            {Object.entries(CATEGORY_CRITERIA).map(([cat, criteria]) => (
              <div key={cat} className="space-y-4">
                <h4 className="font-bold text-emerald-500 border-b border-white/5 pb-2">{cat}</h4>
                <div className="space-y-2">
                  {criteria.map((c) => (
                    <div key={c.name} className="flex justify-between text-sm">
                      <span className="text-zinc-400">{c.name}</span>
                      <span className="font-mono text-emerald-400">{(c.weight * 100).toFixed(0)}%</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
