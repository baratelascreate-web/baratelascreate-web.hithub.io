import React, { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { Search, Loader2, AlertCircle, TrendingUp, Star, ExternalLink } from 'lucide-react';
import { motion } from 'motion/react';
import { Product } from '../types';
import { formatCurrency } from '../utils';
import PublicityBanner from '../components/PublicityBanner';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchProducts = async () => {
      if (!query.trim()) return;

      setLoading(true);
      setError(null);
      try {
        const response = await fetch(`https://api.mercadolibre.com/sites/MLB/search?q=${encodeURIComponent(query)}&limit=20`);
        if (!response.ok) throw new Error('Erro ao buscar produtos');
        const data = await response.json();
        
        const mappedProducts: Product[] = data.results.map((p: any, i: number) => {
          // Calculate a mock tech score based on price and popularity (simulating the snippet's logic)
          const score = p.price > 0 ? Math.min(10, (10000 / p.price) + (p.sold_quantity / 100)).toFixed(1) : "0.0";
          
          return {
            id: p.id,
            title: p.title,
            price: p.price,
            originalPrice: p.original_price || p.price * 1.15,
            store: 'Mercado Livre',
            imageUrl: p.thumbnail.replace("-I.jpg", "-V.jpg"),
            affiliateLink: p.permalink,
            category: 'Celulares', // Default category for search
            specs: {},
            techScore: parseFloat(score),
            isOfferOfDay: i === 0
          };
        });

        // Sort by tech score descending
        mappedProducts.sort((a, b) => (b.techScore || 0) - (a.techScore || 0));
        setProducts(mappedProducts);
      } catch (err: any) {
        console.error("Erro ao buscar:", err);
        setError("Não foi possível carregar os resultados. Tente novamente.");
      } finally {
        setLoading(false);
      }
    };

    fetchProducts();
  }, [query]);

  return (
    <main className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-3xl font-bold mb-2 flex items-center gap-3">
            <Search className="text-emerald-500" />
            Resultados para: <span className="text-emerald-400">"{query}"</span>
          </h1>
          <p className="text-zinc-500">Encontramos as melhores ofertas para você no Mercado Livre</p>
        </div>
        
        <div className="flex items-center gap-2 bg-zinc-900/50 border border-white/5 px-4 py-2 rounded-2xl">
          <TrendingUp className="text-blue-500 w-5 h-5" />
          <span className="text-sm font-medium">Ordenado por Score Inteligente</span>
        </div>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4">
          <Loader2 className="w-12 h-12 text-emerald-500 animate-spin" />
          <p className="text-zinc-500 animate-pulse">Analisando milhares de ofertas em tempo real...</p>
        </div>
      ) : error ? (
        <div className="flex flex-col items-center justify-center py-20 gap-4 text-center">
          <AlertCircle className="w-16 h-16 text-red-500 opacity-20" />
          <p className="text-zinc-400 max-w-md">{error}</p>
          <button 
            onClick={() => window.location.reload()}
            className="bg-emerald-500 text-zinc-950 font-bold px-6 py-2 rounded-xl hover:bg-emerald-400 transition-all"
          >
            Tentar Novamente
          </button>
        </div>
      ) : products.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {products.map((product, i) => (
            <motion.div
              key={product.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
              className="glass-card group flex flex-col h-full overflow-hidden"
            >
              <div className="relative aspect-square bg-white p-4 overflow-hidden">
                <img 
                  src={product.imageUrl} 
                  alt={product.title} 
                  className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500"
                  referrerPolicy="no-referrer"
                />
                {i === 0 && (
                  <div className="absolute top-2 left-2 bg-yellow-500 text-zinc-950 text-[10px] font-black px-2 py-1 rounded-md flex items-center gap-1 shadow-lg z-10">
                    <Star className="w-3 h-3 fill-current" /> MELHOR ESCOLHA
                  </div>
                )}
                <div className="absolute bottom-2 right-2 bg-emerald-500 text-zinc-950 text-[10px] font-bold px-2 py-1 rounded-md shadow-lg z-10">
                  SCORE: {product.techScore}
                </div>
              </div>
              
              <div className="p-4 flex flex-col flex-1">
                <div className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest mb-1">
                  {product.store}
                </div>
                <h3 className="font-semibold text-sm line-clamp-none lg:line-clamp-2 mb-4 min-h-[40px] group-hover:text-emerald-400 transition-colors">
                  {product.title}
                </h3>
                
                <div className="mt-auto">
                  <div className="flex flex-col mb-4">
                    <span className="text-xs text-zinc-500 line-through">
                      {formatCurrency(product.originalPrice)}
                    </span>
                    <span className="text-xl font-bold text-white">
                      {formatCurrency(product.price)}
                    </span>
                  </div>
                  
                  <a 
                    href={product.affiliateLink} 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95"
                  >
                    Ver Oferta
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      ) : (
        <div className="text-center py-20">
          <p className="text-zinc-500">Nenhum produto encontrado para sua busca.</p>
        </div>
      )}

      {products.length > 0 && (
        <PublicityBanner 
          imageUrl="https://picsum.photos/seed/tech-ad-search/1200/300" 
          className="mt-16"
        />
      )}
    </main>
  );
}
