import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Product, Category } from '../types';
import { calculateTechScore } from '../utils';
import ProductCard from '../components/ProductCard';
import { motion } from 'motion/react';
import { Filter } from 'lucide-react';
import PublicityBanner from '../components/PublicityBanner';

export default function CategoryPage() {
  const { category } = useParams();
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState<'score' | 'price-asc' | 'price-desc' | 'discount'>('score');

  useEffect(() => {
    async function fetchProducts() {
      setLoading(true);
      try {
        const q = query(collection(db, 'produtos'), where('category', '==', category));
        const snap = await getDocs(q);
        const data = snap.docs.map(doc => {
          const p = { id: doc.id, ...doc.data() } as Product;
          return { ...p, techScore: calculateTechScore(p) };
        });
        setProducts(data);
      } catch (error) {
        // Silently handle error
        // Mock data
        const mock: Product[] = Array.from({ length: 12 }).map((_, i) => ({
          id: `${i}`,
          title: `${category} Modelo Pro Max Ultra ${i + 1}`,
          price: 1500 + i * 200,
          originalPrice: 2500 + i * 250,
          store: ['Amazon', 'Magalu', 'Kabum'][i % 3],
          imageUrl: `https://picsum.photos/seed/${category}${i}/400/400`,
          affiliateLink: '#',
          category: category as Category,
          specs: { 'Info': 'Especificação de exemplo' }
        })).map(p => ({...p, techScore: calculateTechScore(p)}));
        setProducts(mock);
      } finally {
        setLoading(false);
      }
    }

    fetchProducts();
  }, [category]);

  const sortedProducts = [...products].sort((a, b) => {
    if (sortBy === 'score') return (b.techScore || 0) - (a.techScore || 0);
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'discount') {
      const discountA = (a.originalPrice - a.price) / a.originalPrice;
      const discountB = (b.originalPrice - b.price) / b.originalPrice;
      return discountB - discountA;
    }
    return 0;
  });

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div></div>;

  return (
    <main className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 mb-12">
        <div>
          <h1 className="text-4xl font-bold tracking-tight mb-2">{category}</h1>
          <p className="text-zinc-500">{products.length} produtos encontrados</p>
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 bg-zinc-900 border border-white/5 px-4 py-2 rounded-xl">
            <Filter className="w-4 h-4 text-zinc-500" />
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="bg-transparent text-sm focus:outline-none cursor-pointer"
            >
              <option value="score">Melhor Tech Score</option>
              <option value="discount">Maior Desconto</option>
              <option value="price-asc">Menor Preço</option>
              <option value="price-desc">Maior Preço</option>
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {sortedProducts.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>

      <PublicityBanner 
        imageUrl={`https://picsum.photos/seed/tech-ad-cat-${category}/1200/300`} 
        className="mt-16"
      />
    </main>
  );
}
