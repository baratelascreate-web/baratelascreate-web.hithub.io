import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { doc, getDoc, collection, query, where, getDocs, addDoc, orderBy, onSnapshot } from 'firebase/firestore';
import { db, auth } from '../firebase';
import { Product, Comment } from '../types';
import { formatCurrency, calculateTechScore } from '../utils';
import { motion, AnimatePresence } from 'motion/react';
import { ExternalLink, Star, ShieldCheck, Store, ChevronRight, Info, MessageSquare, Send, User } from 'lucide-react';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider } from 'firebase/auth';
import PublicityBanner from '../components/PublicityBanner';

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [otherStores, setOtherStores] = useState<Partial<Product>[]>([]);
  const [comments, setComments] = useState<Comment[]>([]);
  const [showAllComments, setShowAllComments] = useState(false);
  const [newComment, setNewComment] = useState('');
  const [rating, setRating] = useState(5);
  const [user, setUser] = useState(auth.currentUser);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (u) => setUser(u));
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    if (!id) return;
    
    const q = query(
      collection(db, 'comentarios'),
      where('productId', '==', id),
      orderBy('timestamp', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Comment));
      setComments(docs);
    });

    return () => unsubscribe();
  }, [id]);

  useEffect(() => {
    async function fetchProduct() {
      try {
        const docRef = doc(db, 'produtos', id!);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const data = { id: docSnap.id, ...docSnap.data() } as Product;
          const score = calculateTechScore(data);
          setProduct({ ...data, techScore: score });

          // Search for same product in other stores
          // In a real app, you'd search by a unique identifier like EAN or a normalized name
          const q = query(
            collection(db, 'produtos'), 
            where('title', '==', data.title),
            where('id', '!=', data.id)
          );
          const otherSnap = await getDocs(q);
          const others = otherSnap.docs.map(d => d.data() as Partial<Product>);
          
          // Add current product to the list for comparison
          const allPrices = [
            { store: data.store, price: data.price, affiliateLink: data.affiliateLink },
            ...others.map(o => ({ store: o.store!, price: o.price!, affiliateLink: o.affiliateLink! }))
          ].sort((a, b) => a.price - b.price);

          setOtherStores(allPrices);
        } else {
          // Mock data for demo
          const mock: Product = {
            id: id!,
            title: 'Samsung Galaxy S24 Ultra 512GB Titanium Gray',
            price: 6999,
            originalPrice: 8999,
            store: 'Magalu',
            imageUrl: 'https://picsum.photos/seed/s24/600/600',
            affiliateLink: '#',
            category: 'Celulares',
            specs: {
              'Processador': 'Snapdragon 8 Gen 3',
              'RAM': '12GB',
              'Armazenamento': '512GB',
              'Tela': '6.8" Dynamic AMOLED 2X',
              'Câmera': '200MP + 50MP + 12MP + 10MP',
              'Bateria': '5000mAh'
            }
          };
          setProduct({ ...mock, techScore: calculateTechScore(mock) });
          setOtherStores([
            { store: 'Magalu', price: 6999, affiliateLink: '#' },
            { store: 'Amazon', price: 7199, affiliateLink: '#' },
            { store: 'Mercado Livre', price: 7499, affiliateLink: '#' },
            { store: 'Kabum', price: 7050, affiliateLink: '#' }
          ].sort((a, b) => a.price - b.price));
        }
      } catch (error) {
        // Silently handle error
      } finally {
        setLoading(false);
      }
    }

    fetchProduct();
  }, [id]);

  const handleLogin = async () => {
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
    } catch (error) {
      console.error("Login failed", error);
    }
  };

  const handleSubmitComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newComment.trim() || !id) return;

    setSubmitting(true);
    try {
      await addDoc(collection(db, 'comentarios'), {
        productId: id,
        userId: user.uid,
        userName: user.displayName || 'Usuário',
        userPhoto: user.photoURL || '',
        text: newComment.trim(),
        rating,
        timestamp: Date.now()
      });
      setNewComment('');
      setRating(5);
    } catch (error) {
      console.error("Error adding comment", error);
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    if (window.location.hash === '#comments' && !loading) {
      const element = document.getElementById('comments');
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  }, [loading]);

  if (loading) return <div className="min-h-screen flex items-center justify-center"><div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin"></div></div>;
  if (!product) return <div className="min-h-screen flex items-center justify-center">Produto não encontrado</div>;

  return (
    <main className="max-w-7xl mx-auto px-4 py-12">
      {/* Breadcrumbs */}
      <nav className="flex items-center gap-2 text-sm text-zinc-500 mb-8">
        <Link to="/" className="hover:text-white">Home</Link>
        <ChevronRight className="w-4 h-4" />
        <Link to={`/categoria/${product.category}`} className="hover:text-white">{product.category}</Link>
        <ChevronRight className="w-4 h-4" />
        <span className="text-zinc-300 truncate max-w-[200px]">{product.title}</span>
      </nav>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
        {/* Left: Image */}
        <motion.div 
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          className="glass-card bg-white p-8 flex items-center justify-center"
        >
          <img 
            src={product.imageUrl} 
            alt={product.title} 
            className="max-w-full max-h-[500px] object-contain"
            referrerPolicy="no-referrer"
          />
        </motion.div>

        {/* Right: Info */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex flex-col"
        >
          <div className="flex items-center gap-3 mb-4">
            <span className="bg-emerald-500/10 text-emerald-500 text-xs font-bold px-3 py-1 rounded-full uppercase tracking-widest">
              {product.store}
            </span>
            <div className="flex items-center gap-1 bg-zinc-900 px-3 py-1 rounded-full border border-white/5">
              <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
              <span className="text-sm font-bold">{product.techScore}</span>
              <span className="text-xs text-zinc-500">Tech Score</span>
              <Link to="/como-funciona" className="ml-1"><Info className="w-3 h-3 text-zinc-500 hover:text-white" /></Link>
            </div>
            <a href="#comments" className="text-xs text-zinc-500 hover:text-emerald-500 transition-colors flex items-center gap-1">
              <MessageSquare className="w-3 h-3" />
              {comments.length} avaliações
            </a>
          </div>

          <h1 className="text-3xl md:text-4xl font-bold mb-6 leading-tight">
            {product.title}
          </h1>

          <div className="glass-card p-6 mb-8">
            <div className="flex flex-col mb-6">
              <span className="text-zinc-500 line-through text-lg">
                {formatCurrency(product.originalPrice)}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-bold text-white">
                  {formatCurrency(product.price)}
                </span>
                <span className="text-emerald-500 font-medium">
                  ({Math.round((1 - product.price / product.originalPrice) * 100)}% OFF)
                </span>
              </div>
            </div>

            <a
              href={product.affiliateLink}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-4 rounded-2xl flex items-center justify-center gap-2 text-lg transition-all active:scale-95 shadow-lg shadow-emerald-500/20"
            >
              Ir para a Loja
              <ExternalLink className="w-5 h-5" />
            </a>
          </div>

          <div className="space-y-4">
            <h3 className="font-bold text-lg flex items-center gap-2">
              <ShieldCheck className="text-emerald-500 w-5 h-5" />
              Especificações Detalhadas
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {Object.entries(product.specs).map(([key, value]) => (
                <div key={key} className="bg-zinc-900/50 border border-white/5 p-3 rounded-xl">
                  <span className="text-xs text-zinc-500 block uppercase tracking-widest mb-1">{key}</span>
                  <span className="text-sm font-medium">{value}</span>
                </div>
              ))}
            </div>
          </div>
        </motion.div>
      </div>

      {/* Price Comparison */}
      <section className="glass-card p-8 mb-16">
        <h2 className="text-2xl font-bold mb-8 flex items-center gap-2">
          <Store className="text-emerald-500" />
          Comparar Preços em Outras Lojas
        </h2>
        <div className="space-y-4">
          {otherStores.map((store, index) => (
            <div 
              key={index}
              className={`flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-4 rounded-2xl border transition-all ${
                index === 0 
                  ? 'bg-emerald-500/10 border-emerald-500/50' 
                  : 'bg-zinc-900/50 border-white/5 hover:border-white/20'
              }`}
            >
              <div className="flex items-center gap-4">
                <div className={`w-10 h-10 shrink-0 rounded-full flex items-center justify-center font-bold ${
                  index === 0 ? 'bg-emerald-500 text-zinc-950' : 'bg-zinc-800 text-zinc-400'
                }`}>
                  {index + 1}
                </div>
                <div>
                  <span className="font-bold text-lg block">{store.store}</span>
                  {index === 0 && <span className="text-[10px] bg-emerald-500 text-zinc-950 px-2 py-0.5 rounded font-bold uppercase">Melhor Preço</span>}
                </div>
              </div>
              <div className="flex items-center justify-between sm:justify-end gap-4 w-full sm:w-auto">
                <span className={`text-xl font-bold ${index === 0 ? 'text-emerald-400' : 'text-white'}`}>
                  {formatCurrency(store.price!)}
                </span>
                <a
                  href={store.affiliateLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className={`px-6 py-2 rounded-xl font-bold text-center whitespace-nowrap transition-all active:scale-95 ${
                    index === 0 
                      ? 'bg-emerald-500 text-zinc-950 hover:bg-emerald-400' 
                      : 'bg-zinc-800 text-white hover:bg-zinc-700'
                  }`}
                >
                  Ir à Loja
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      <PublicityBanner 
        imageUrl="https://picsum.photos/seed/tech-ad-product/1200/300" 
        className="mb-16"
      />

      {/* Comments Section */}
      <section id="comments" className="glass-card p-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <MessageSquare className="text-emerald-500" />
            Comentários e Avaliações
          </h2>
          <div className="flex items-center gap-2 bg-zinc-900 px-4 py-2 rounded-xl border border-white/5">
            <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
            <span className="text-lg font-bold">
              {comments.length > 0 
                ? (comments.reduce((acc, curr) => acc + curr.rating, 0) / comments.length).toFixed(1)
                : '0.0'}
            </span>
            <span className="text-sm text-zinc-500">({comments.length} avaliações)</span>
          </div>
        </div>

        {/* Add Comment Form */}
        <div className="mb-12 p-6 bg-zinc-900/50 rounded-3xl border border-white/5">
          {user ? (
            <form onSubmit={handleSubmitComment}>
              <div className="flex items-center gap-4 mb-4">
                {user.photoURL ? (
                  <img src={user.photoURL} alt={user.displayName || ''} className="w-10 h-10 rounded-full" />
                ) : (
                  <div className="w-10 h-10 rounded-full bg-emerald-500 flex items-center justify-center text-zinc-950 font-bold">
                    {user.displayName?.[0] || 'U'}
                  </div>
                )}
                <div className="flex-1">
                  <p className="text-sm font-bold">{user.displayName}</p>
                  <div className="flex gap-1 mt-1">
                    {[1, 2, 3, 4, 5].map((s) => (
                      <button
                        key={s}
                        type="button"
                        onClick={() => setRating(s)}
                        className="focus:outline-none"
                      >
                        <Star className={`w-5 h-5 ${s <= rating ? 'text-yellow-500 fill-yellow-500' : 'text-zinc-700'}`} />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              <textarea
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="O que você achou deste produto?"
                className="w-full bg-zinc-950 border border-white/10 rounded-2xl p-4 text-white placeholder:text-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-colors mb-4 resize-none h-32"
              />
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={submitting || !newComment.trim()}
                  className="bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 disabled:hover:bg-emerald-500 text-zinc-950 font-bold px-8 py-3 rounded-xl flex items-center gap-2 transition-all active:scale-95"
                >
                  {submitting ? 'Enviando...' : 'Publicar Comentário'}
                  <Send className="w-4 h-4" />
                </button>
              </div>
            </form>
          ) : (
            <div className="text-center py-8">
              <p className="text-zinc-400 mb-6">Faça login para deixar sua avaliação sobre este produto.</p>
              <button
                onClick={handleLogin}
                className="bg-white text-zinc-950 font-bold px-8 py-3 rounded-xl hover:bg-zinc-200 transition-all active:scale-95 flex items-center gap-2 mx-auto"
              >
                <User className="w-5 h-5" />
                Entrar com Google
              </button>
            </div>
          )}
        </div>

        {/* Comments List */}
        <div className="space-y-6">
          <AnimatePresence mode="popLayout">
            {comments.length > 0 ? (
              <>
                {(showAllComments ? comments : comments.slice(0, 3)).map((comment) => (
                  <motion.div
                    key={comment.id}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    className="p-6 bg-zinc-900/30 rounded-3xl border border-white/5"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <div className="flex items-center gap-3">
                        {comment.userPhoto ? (
                          <img src={comment.userPhoto} alt={comment.userName} className="w-10 h-10 rounded-full" />
                        ) : (
                          <div className="w-10 h-10 rounded-full bg-zinc-800 flex items-center justify-center text-zinc-500 font-bold">
                            {comment.userName[0]}
                          </div>
                        )}
                        <div>
                          <p className="font-bold text-sm">{comment.userName}</p>
                          <div className="flex gap-0.5">
                            {[1, 2, 3, 4, 5].map((s) => (
                              <Star key={s} className={`w-3 h-3 ${s <= comment.rating ? 'text-yellow-500 fill-yellow-500' : 'text-zinc-800'}`} />
                            ))}
                          </div>
                        </div>
                      </div>
                      <span className="text-xs text-zinc-600">
                        {new Date(comment.timestamp).toLocaleDateString('pt-BR')}
                      </span>
                    </div>
                    <p className="text-zinc-300 leading-relaxed">
                      {comment.text}
                    </p>
                  </motion.div>
                ))}
                
                {comments.length > 3 && !showAllComments && (
                  <button
                    onClick={() => setShowAllComments(true)}
                    className="w-full py-4 text-emerald-500 font-bold hover:text-emerald-400 transition-colors flex items-center justify-center gap-2 border border-dashed border-emerald-500/20 rounded-2xl"
                  >
                    Ver Mais Comentários
                    <ChevronRight className="w-4 h-4 rotate-90" />
                  </button>
                )}
              </>
            ) : (
              <div className="text-center py-12 text-zinc-500">
                <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-20" />
                <p>Nenhum comentário ainda. Seja o primeiro a avaliar!</p>
              </div>
            )}
          </AnimatePresence>
        </div>
      </section>
    </main>
  );
}
