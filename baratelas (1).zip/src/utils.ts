import { CATEGORY_CRITERIA, Category, Product } from './types';

/**
 * Calculates a Tech Score from 0 to 10 based on category criteria.
 * In a real scenario, these scores for each criteria would come from the database
 * or be calculated based on raw specs. Here we simulate the calculation logic.
 */
export function calculateTechScore(product: Product): number {
  const criteria = CATEGORY_CRITERIA[product.category];
  if (!criteria) return 0;

  // This is a simplified simulation. In a real app, you'd map specs to scores.
  // For this demo, we'll use a deterministic "random" based on title + specs string
  // to ensure products with same name and specs have the same score.
  const seedString = `${product.title}-${JSON.stringify(product.specs)}`;
  let hash = 0;
  for (let i = 0; i < seedString.length; i++) {
    hash = seedString.charCodeAt(i) + ((hash << 5) - hash);
  }

  let totalScore = 0;
  criteria.forEach((c, index) => {
    // Generate a "score" between 6 and 10 for each criteria based on the hash
    const criteriaScore = 6 + (Math.abs(hash + index) % 41) / 10; 
    totalScore += criteriaScore * c.weight;
  });

  return Math.min(10, Math.max(0, parseFloat(totalScore.toFixed(1))));
}

export function formatCurrency(value: number): string {
  return new Intl.NumberFormat('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  }).format(value);
}
