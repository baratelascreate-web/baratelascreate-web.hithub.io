import React, { useState, useEffect, useRef } from 'react';
import { Search, Moon, Sun, Menu, X, Cpu, Info, ChevronRight, ChevronDown, ChevronUp } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { Category, Product } from '../types';
import { useTheme } from '../context/ThemeContext';
import { motion, AnimatePresence } from 'motion/react';
import { collection, getDocs, query } from 'firebase/firestore';
import { db } from '../firebase';

const CATEGORIES: Category[] = ['Celulares', 'Notebooks', 'Tablets', 'Monitores Gamer', 'TVs'];

export default function Header() {
  const { theme, toggleTheme } = useTheme();
  const [searchQuery, setSearchQuery] = useState('');
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCategoriesVisible, setIsCategoriesVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);
  const [isCategoriesExpanded, setIsCategoriesExpanded] = useState(true);
  const [searchResults, setSearchResults] = useState<Product[]>([]);
  const [isSearchFocused, setIsSearchFocused] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);
  const mobileSearchRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchSearchResults = async () => {
      if (!searchQuery.trim()) {
        setSearchResults([]);
        return;
      }
      try {
        // Fetch from Mercado Livre for live preview
        const response = await fetch(`https://api.mercadolibre.com/sites/MLB/search?q=${encodeURIComponent(searchQuery)}&limit=5`);
        if (!response.ok) throw new Error('Erro ao buscar');
        const data = await response.json();
        
        const mappedResults: Product[] = data.results.map((p: any) => ({
          id: p.id,
          title: p.title,
          price: p.price,
          originalPrice: p.original_price || p.price * 1.15,
          store: 'Mercado Livre',
          imageUrl: p.thumbnail.replace("-I.jpg", "-V.jpg"),
          affiliateLink: p.permalink,
          category: 'Celulares',
          specs: {},
          techScore: parseFloat(Math.min(10, (10000 / p.price) + (p.sold_quantity / 100)).toFixed(1))
        }));
        
        setSearchResults(mappedResults);
      } catch (error) {
        // Silently handle error
      }
    };

    const debounce = setTimeout(fetchSearchResults, 300);
    return () => clearTimeout(debounce);
  }, [searchQuery]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
      if (mobileSearchRef.current && !mobileSearchRef.current.contains(event.target as Node)) {
        setIsSearchFocused(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const controlNavbar = () => {
      if (typeof window !== 'undefined') {
        if (window.scrollY > lastScrollY && window.scrollY > 150) {
          // Scrolling down
          setIsCategoriesVisible(false);
        } else {
          // Scrolling up
          setIsCategoriesVisible(true);
        }
        setLastScrollY(window.scrollY);
      }
    };

    window.addEventListener('scroll', controlNavbar);
    return () => window.removeEventListener('scroll', controlNavbar);
  }, [lastScrollY]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/search?q=${encodeURIComponent(searchQuery)}`);
      setIsMenuOpen(false);
      setIsSearchFocused(false);
    }
  };

  const handleProductClick = (product: Product) => {
    if (product.store === 'Mercado Livre') {
      window.open(product.affiliateLink, '_blank');
    } else {
      navigate(`/produto/${product.id}`);
    }
    setIsSearchFocused(false);
    setIsMenuOpen(false);
  };

  const closeMenu = () => setIsMenuOpen(false);

  return (
    <>
    <header className="bg-blue-700 backdrop-blur-xl border-b border-white/10 sticky top-0 z-50 transition-colors duration-300">
      <div className="max-w-7xl mx-auto px-4">
        {/* Top Bar */}
        <div className="flex items-center justify-between h-16 gap-4">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="p-2 -ml-2 rounded-full hover:bg-blue-800 transition-colors md:hidden"
              aria-label="Open menu"
            >
              <Menu className="w-6 h-6 text-white" />
            </button>

            <button 
              onClick={() => setIsCategoriesExpanded(!isCategoriesExpanded)}
              className="hidden md:flex items-center gap-2 p-2 rounded-lg hover:bg-blue-800 transition-colors text-white group"
              aria-label="Toggle categories"
            >
              <Menu className="w-5 h-5" />
              <span className="text-sm font-semibold">Categorias</span>
              {isCategoriesExpanded ? <ChevronUp className="w-4 h-4 text-emerald-400" /> : <ChevronDown className="w-4 h-4 text-emerald-400" />}
            </button>
            
            <Link to="/" className="flex items-center gap-2 group shrink-0">
              <div className="w-10 h-10 bg-white rounded-lg flex items-center justify-center group-hover:rotate-12 transition-transform">
                <Cpu className="text-blue-700 w-6 h-6" />
              </div>
              <span className="text-xl font-bold tracking-tighter text-white">
                BARA<span className="text-emerald-400">TELAS</span>
              </span>
            </Link>
          </div>

          {/* Desktop Search */}
          <div ref={searchRef} className="hidden md:flex flex-1 max-w-2xl relative group">
            <form onSubmit={handleSearch} className="w-full relative">
              <input
                type="text"
                placeholder="Pesquisar produtos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                className="w-full bg-blue-800/50 border border-white/20 rounded-full py-2 px-10 focus:outline-none focus:ring-2 focus:ring-emerald-400/50 transition-all text-white placeholder:text-black"
                autoComplete="off"
              />
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400 group-focus-within:text-emerald-300" />
            </form>

            {/* Search Preview Dropdown */}
            <AnimatePresence>
              {isSearchFocused && searchQuery.trim() && searchResults.length > 0 && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className="absolute top-full mt-2 w-full bg-white dark:bg-zinc-900 rounded-xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden z-50"
                >
                  <div className="p-2">
                    {searchResults.map(product => (
                      <button
                        key={product.id}
                        type="button"
                        onClick={() => handleProductClick(product)}
                        className="w-full flex items-center gap-4 p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors text-left"
                      >
                        <img src={product.imageUrl} alt={product.title} className="w-12 h-12 object-contain rounded-md bg-white" />
                        <div>
                          <h4 className="text-sm font-medium text-zinc-900 dark:text-white line-clamp-1">{product.title}</h4>
                          <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                            {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <button 
            onClick={toggleTheme}
            className="p-2 rounded-full bg-emerald-400 text-blue-700 hover:bg-emerald-300 transition-all shadow-lg"
            aria-label="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile Search Bar */}
        <div ref={mobileSearchRef} className="md:hidden pb-4 relative">
          <form onSubmit={handleSearch} className="relative group w-full">
            <input
              type="text"
              placeholder="Pesquisar produtos..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              className="w-full bg-blue-800/50 border border-white/20 rounded-full py-2 px-10 focus:outline-none focus:ring-2 focus:ring-emerald-400/50 transition-all text-white placeholder:text-black"
              autoComplete="off"
            />
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-400 group-focus-within:text-emerald-300" />
          </form>

          {/* Mobile Search Preview Dropdown */}
          <AnimatePresence>
            {isSearchFocused && searchQuery.trim() && searchResults.length > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: 10 }}
                className="absolute top-full mt-2 w-full bg-white dark:bg-zinc-900 rounded-xl shadow-2xl border border-zinc-200 dark:border-zinc-800 overflow-hidden z-50"
              >
                <div className="p-2">
                  {searchResults.map(product => (
                    <button
                      key={product.id}
                      type="button"
                      onClick={() => handleProductClick(product)}
                      className="w-full flex items-center gap-4 p-2 hover:bg-zinc-100 dark:hover:bg-zinc-800 rounded-lg transition-colors text-left"
                    >
                      <img src={product.imageUrl} alt={product.title} className="w-12 h-12 object-contain rounded-md bg-white" />
                      <div>
                        <h4 className="text-sm font-medium text-zinc-900 dark:text-white line-clamp-1">{product.title}</h4>
                        <span className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                          {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Desktop Categories Bar */}
        <AnimatePresence>
          {(isCategoriesVisible || isCategoriesExpanded) && (
            <motion.nav 
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.2 }}
              className="hidden md:flex items-center justify-center gap-6 py-3 border-t border-white/10 overflow-hidden"
            >
              {CATEGORIES.map((cat) => (
                <Link
                  key={cat}
                  to={`/categoria/${cat}`}
                  className="text-sm font-medium text-blue-100 hover:text-white hover:bg-white/10 px-3 py-1.5 rounded-lg whitespace-nowrap transition-all"
                >
                  {cat}
                </Link>
              ))}
            </motion.nav>
          )}
        </AnimatePresence>
      </div>
    </header>

      {/* Mobile Menu Sidebar */}
      <AnimatePresence>
        {isMenuOpen && (
          <>
            {/* Backdrop */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={closeMenu}
              className="fixed inset-0 bg-zinc-950/60 backdrop-blur-sm z-[60]"
            />
            
            {/* Sidebar */}
            <motion.div
              initial={{ x: '-100%' }}
              animate={{ x: 0 }}
              exit={{ x: '-100%' }}
              transition={{ type: 'spring', damping: 25, stiffness: 200 }}
              className="fixed inset-y-0 left-0 w-[280px] bg-blue-700 border-r border-white/10 z-[70] p-6 shadow-2xl"
            >
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                    <Cpu className="text-blue-700 w-5 h-5" />
                  </div>
                  <span className="font-bold tracking-tighter text-white">BARA<span className="text-emerald-400">TELAS</span></span>
                </div>
                <button onClick={closeMenu} className="p-2 hover:bg-blue-800 rounded-full transition-colors">
                  <X className="w-6 h-6 text-white" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <h3 className="text-[10px] font-bold text-emerald-400 uppercase tracking-[0.2em] mb-4">Categorias</h3>
                  <div className="space-y-1">
                    {CATEGORIES.map((cat) => (
                      <Link
                        key={cat}
                        to={`/categoria/${cat}`}
                        onClick={closeMenu}
                        className="flex items-center justify-between w-full p-3 rounded-xl hover:bg-white/10 text-blue-100 hover:text-white transition-all group"
                      >
                        <span className="font-medium">{cat}</span>
                        <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                      </Link>
                    ))}
                  </div>
                </div>

                <div className="pt-6 border-t border-white/10">
                  <Link
                    to="/como-funciona"
                    onClick={closeMenu}
                    className="flex items-center gap-3 p-3 rounded-xl bg-white/10 border border-white/20 text-white hover:bg-white/20 transition-all"
                  >
                    <Info className="w-5 h-5" />
                    <span className="font-semibold">Como funciona o Tech Score</span>
                  </Link>
                </div>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
