import React from 'react';

interface PublicityBannerProps {
  imageUrl?: string;
  link?: string;
  className?: string;
}

const PublicityBanner: React.FC<PublicityBannerProps> = ({ 
  imageUrl = 'https://picsum.photos/seed/ads/1200/300', 
  link = '#',
  className = ''
}) => {
  return (
    <div className={`w-full my-12 ${className}`}>
      {/* Header with Label and Line */}
      <div className="flex items-center gap-4 mb-4">
        <span className="text-[10px] font-bold tracking-widest text-zinc-500 uppercase whitespace-nowrap">
          Publicidade
        </span>
        <div className="h-[1px] w-full bg-zinc-200 dark:bg-zinc-800" />
      </div>

      {/* Banner Image Container */}
      <a 
        href={link} 
        target="_blank" 
        rel="noopener noreferrer"
        className="block relative group overflow-hidden rounded-lg shadow-sm hover:shadow-md transition-shadow"
      >
        <div className="absolute top-3 left-3 z-10">
          <span className="text-[9px] font-medium text-white/70 bg-black/20 backdrop-blur-sm px-2 py-0.5 rounded border border-white/10 uppercase tracking-wider">
            Publicidade
          </span>
        </div>
        
        <img 
          src={imageUrl} 
          alt="Publicidade" 
          className="w-full h-auto object-cover min-h-[120px] max-h-[300px] group-hover:scale-[1.01] transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        
        {/* Overlay for hover effect */}
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors duration-300" />
      </a>
    </div>
  );
};

export default PublicityBanner;
