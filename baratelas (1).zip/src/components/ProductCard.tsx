import React from 'react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';
import { ExternalLink, Star, Award, Percent, Tag } from 'lucide-react';
import { Product } from '../types';
import { formatCurrency, calculateTechScore } from '../utils';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const score = product.techScore || calculateTechScore(product);
  const rating = product.rating || 0;
  const discountPercent = product.originalPrice > 0 ? ((product.originalPrice - product.price) / product.originalPrice) * 100 : 0;
  
  const getScoreColor = (s: number) => {
    if (s >= 9) return 'bg-emerald-500';
    if (s >= 7) return 'bg-blue-500';
    if (s >= 5) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const renderBadge = () => {
    if (score >= 9.5 && rating >= 5) {
      return (
        <span className="inline-flex items-center gap-1 bg-red-600 text-white text-[8px] font-black px-2 py-0.5 rounded-full shadow-sm animate-pulse ml-2">
          <Award className="w-2.5 h-2.5 fill-white" />
          ESCOLHA TECH
        </span>
      );
    }
    if (score >= 8 && discountPercent >= 20) {
      return (
        <span className="inline-flex items-center gap-1 bg-yellow-400 text-zinc-950 text-[8px] font-black px-2 py-0.5 rounded-full shadow-sm ml-2">
          <Percent className="w-2.5 h-2.5" />
          CUSTO-BENEFÍCIO
        </span>
      );
    }
    if (discountPercent >= 40) {
      return (
        <span className="inline-flex items-center gap-1 bg-orange-500 text-white text-[8px] font-black px-2 py-0.5 rounded-full shadow-sm ml-2">
          <Tag className="w-2.5 h-2.5 fill-white" />
          OFERTA TECH
        </span>
      );
    }
    return null;
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="glass-card group flex flex-col h-full"
    >
      <div className="relative aspect-square overflow-hidden bg-white p-4">
        <img
          src={product.imageUrl}
          alt={product.title}
          className="w-full h-full object-contain group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className={`absolute top-2 right-2 tech-score-badge w-10 h-10 text-xs shadow-lg ${getScoreColor(score)} text-zinc-950`}>
          {score}
        </div>
        {product.isOfferOfDay && (
          <div className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-1 rounded uppercase tracking-tighter">
            Oferta do Dia
          </div>
        )}
      </div>

      <div className="p-4 flex flex-col flex-1">
        <div className="flex items-center mb-1">
          <div className="text-[10px] text-emerald-500 font-bold uppercase tracking-widest">
            {product.store}
          </div>
          {renderBadge()}
        </div>
        <h3 className="text-sm font-semibold line-clamp-none lg:line-clamp-2 mb-3 min-h-[40px] group-hover:text-emerald-400 transition-colors">
          {product.title}
        </h3>

        <div className="mt-auto">
          <div className="flex flex-col mb-4">
            <span className="text-xs text-zinc-500 line-through">
              {formatCurrency(product.originalPrice)}
            </span>
            <span className="text-xl font-bold text-white">
              {formatCurrency(product.price)}
            </span>
          </div>

          <Link
            to={`/produto/${product.id}`}
            className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-2.5 rounded-xl flex items-center justify-center gap-2 transition-all active:scale-95"
          >
            Ver Oferta
            <ExternalLink className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </motion.div>
  );
};

export default ProductCard;
