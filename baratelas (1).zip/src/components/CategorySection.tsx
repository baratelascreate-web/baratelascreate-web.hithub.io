import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Product, Category } from '../types';
import ProductCard from './ProductCard';

interface CategorySectionProps {
  category: Category;
  products: Product[];
}

const CategorySection: React.FC<CategorySectionProps> = ({ category, products }) => {
  return (
    <section className="py-12">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">{category}</h2>
          <p className="text-zinc-500 text-sm">Top avaliados pelo Tech Score</p>
        </div>
        <Link 
          to={`/categoria/${category}`}
          className="flex items-center gap-1 text-emerald-500 hover:text-emerald-400 font-medium transition-colors"
        >
          Ver mais
          <ChevronRight className="w-4 h-4" />
        </Link>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {products.slice(0, 4).map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
};

export default CategorySection;
