import { Link } from 'react-router-dom';
import { Cpu } from 'lucide-react';
import { Category } from '../types';

const CATEGORIES: Category[] = ['Celulares', 'Notebooks', 'Tablets', 'Monitores Gamer', 'TVs'];

export default function Footer() {
  return (
    <footer className="bg-blue-700 border-t border-white/10 pt-16 pb-8 text-white">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <Link to="/" className="flex items-center gap-2 mb-6">
              <div className="w-8 h-8 bg-white rounded flex items-center justify-center">
                <Cpu className="text-blue-700 w-5 h-5" />
              </div>
              <span className="text-xl font-bold tracking-tighter text-white">
                BARA<span className="text-emerald-400">TELAS</span>
              </span>
            </Link>
            <p className="text-blue-100 max-w-md leading-relaxed">
              Sua central definitiva de tecnologia. Analisamos e centralizamos as melhores ofertas 
              com nosso sistema exclusivo de Tech Score para garantir que você faça sempre a melhor escolha.
            </p>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-emerald-400 uppercase tracking-widest text-xs">Categorias</h4>
            <ul className="space-y-4">
              {CATEGORIES.map((cat) => (
                <li key={cat}>
                  <Link to={`/categoria/${cat}`} className="text-blue-100 hover:text-white transition-colors">
                    {cat}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-bold mb-6 text-emerald-400 uppercase tracking-widest text-xs">Institucional</h4>
            <ul className="space-y-4">
              <li>
                <Link to="/como-funciona" className="text-blue-100 hover:text-white transition-colors">
                  Como funciona o Tech Score
                </Link>
              </li>
              <li>
                <Link to="/privacidade" className="text-blue-100 hover:text-white transition-colors">
                  Política de Privacidade
                </Link>
              </li>
              <li>
                <Link to="/termos" className="text-blue-100 hover:text-white transition-colors">
                  Termos de Uso
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 text-center text-blue-200 text-sm">
          <p>© {new Date().getFullYear()} BARATELAS. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
